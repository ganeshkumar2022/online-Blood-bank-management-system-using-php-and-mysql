<nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-center" style="bottom:0;position:absolute;width:100%;">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="#">Made by R.Ganesh kumar<br>&copy; copyrights reserved</a>
    </li>
  </ul>
</nav>